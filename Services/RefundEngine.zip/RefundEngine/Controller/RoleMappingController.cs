using Microsoft.AspNetCore.Mvc;

namespace RefundEngine.Controllers;

[ApiController]
[Route("[controller]")]
public class RoleMappingController : ControllerBase
{
    public RoleMappingController()
    {    
    }  
}
