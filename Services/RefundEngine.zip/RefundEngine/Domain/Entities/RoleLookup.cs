using System.ComponentModel.DataAnnotations;

namespace RefundEngine.Domain.Entities;

public class RoleLookup : BaseEntity
{
    [Required]
    [MaxLength(50)]
    public string? Role { get; set; }

    [Required]
    [MaxLength(50)]
    public string? Alias { get; set; }

    [Required]
    public bool IsActive { get; set; }
}