using RefundEngine.Application.Data;
using RefundEngine.Domain.Entities;
using RefundEngine.Repository.Implementation;
using RefundEngine.Repository.IRepository;

namespace RefundEngine.Repository;

public class UnitOfWork : IUnitOfWork
{
    private readonly AppDbContext _context;
    public IGenericRepository<RoleMapping> RoleMappings { get; private set; }

    public UnitOfWork(AppDbContext context)
    {
        _context = context;
        RoleMappings = new GenericRepository<RoleMapping>(_context);
    }
    public async Task<int> CompleteAsync()
    {
        return await _context.SaveChangesAsync();
    }

    public void Dispose()
    {
        _context.Dispose();
    }
}