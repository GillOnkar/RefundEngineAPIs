using RefundEngine.Domain.Entities;

namespace RefundEngine.Services.Interfaces;

public interface IRoleMapping
{
    Task<RoleMapping> AddRoleMappingAsync(Guid userId, Guid roleId);
    Task<IEnumerable<RoleMapping>> GetMappingsByEmailAsync(string EmailId);
    Task<bool> RemoveRoleMappingAsync(Guid userId, Guid roleId);
}