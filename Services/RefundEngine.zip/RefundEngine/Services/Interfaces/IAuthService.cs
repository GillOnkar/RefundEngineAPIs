using System.Security.Claims;

namespace RefundEngine.Services.Interfaces;

public interface IAuthService
{
    string IsValidRole(ClaimsPrincipal user);
}