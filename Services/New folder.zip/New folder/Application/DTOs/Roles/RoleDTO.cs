namespace RefundEngine.Application.DTOs;

public class RoleDTO
{
    public Guid Id { get; set; }
    public string? Role { get; set; }
    public string? Alias { get; set; }
}