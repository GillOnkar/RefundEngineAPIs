using System.ComponentModel.DataAnnotations;

namespace RefundEngine.Application.DTOs.SuperAdmin;

public class SuperAdminUserLoginDTO
{
    [Required]
    [MaxLength(50)]
    public string? EmailId { get; set; }

    [Required]
    [MaxLength(100)]
    public string? Password { get; set; }
}