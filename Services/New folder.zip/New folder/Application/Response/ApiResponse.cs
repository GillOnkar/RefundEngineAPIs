using System.Net;

namespace RefundEngine.Application;

public class ApiResponse
{
    public ApiResponse()
    {
        Errors = [];
    }
    public bool IsSuccess { get; set; } = true;
    public List<string> Errors { get; set; }
    public HttpStatusCode StatusCode { get; set; }
    public object? Result { get; set; }
}
