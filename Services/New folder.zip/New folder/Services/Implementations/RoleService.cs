
using AutoMapper;
using Microsoft.AspNetCore.Authorization.Infrastructure;
using Microsoft.AspNetCore.Mvc;
using RefundEngine.Application.DTOs;
using RefundEngine.Domain.Entities;
using RefundEngine.Repository;
using RefundEngine.Repository.Implementation;
using RefundEngine.Repository.IRepository;
using RefundEngine.Services.Interfaces;

namespace RefundEngine.Services.Implementation;

public class RoleService : IRoleService
{
    private readonly IUnitOfWork _unitOfWork;
    private readonly IMapper _mapper;
    public RoleService(IUnitOfWork unitOfWork, IMapper mapper)
    {
        _unitOfWork = unitOfWork;
        _mapper = mapper;
    }

    public async Task<IEnumerable<RoleDTO>> GetRolesAsync()
    {
        var roles = await _unitOfWork.RoleLookups.GetAllAsync();
        var roleDtos = _mapper.Map<List<RoleDTO>>(roles);
        return roleDtos;
    } 

    public async Task<RoleMappingDTO> AddRoleMappingAsync([FromBody] RoleMappingDTO roleMappingDto)
    {
        var existing = await _unitOfWork.RoleMappings.FindAsync(r => r.EmailId == roleMappingDto.EmailId);

        if (existing.Count() != 0)
            return null; //email already exists

        var entity = _mapper.Map<RoleMapping>(roleMappingDto);
        await _unitOfWork.RoleMappings.AddAsync(entity);
        await _unitOfWork.CompleteAsync();

    // map back to DTO for response
    return _mapper.Map<RoleMappingDTO>(entity);
        // var roleMapping = _unitOfWork.RoleMappings.FindAsync(r => r.EmailId == roleMappingDto.EmailId);
        // if (roleMapping is null)
        // {
        //     var roleMapped = _mapper.Map<RoleMapping>(roleMappingDto);
        //     await _unitOfWork.RoleMappings.AddAsync(roleMapped);
        //     await _unitOfWork.CompleteAsync();
        //     return new RoleMappingDTO();
        // }
        // return new RoleMappingDTO();
    }

    public bool IsUniqueUserEmailId (string userEmailId)
    {
        if (_unitOfWork.RoleMappings.FindAsync(r => r.EmailId == userEmailId) is null)
        {
            return true;
        }
        return false;
    }
}