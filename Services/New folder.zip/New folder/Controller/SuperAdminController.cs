using System.Net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualBasic;
using RefundEngine.Application;
using RefundEngine.Application.DTOs.SuperAdmin;
using RefundEngine.Services.Interfaces;

namespace RefundEngine.Controllers;


[ApiController]
[Route("RefundEngine/api/[controller]/[action]")]
public class SuperAdminController : ControllerBase
{
    
    private readonly ISuperAdminService _superAdminService;
    protected ApiResponse _response;
    public SuperAdminController(ISuperAdminService superAdminService)
    {
         _superAdminService = superAdminService;
        _response = new();
    }

    [HttpPost]
    [ProducesResponseType(typeof(ApiResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse), StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult> Login(SuperAdminUserLoginDTO superAdminUserLoginDTO)
    {
        var isValid = await _superAdminService.ValidatePasswordAsync(superAdminUserLoginDTO);
        if (!isValid)
        {
            _response.Errors.Add("UnAuthorize. Invalid Email or Password");
            _response.IsSuccess = false;
            _response.StatusCode = HttpStatusCode.Unauthorized;
            return Unauthorized(_response);
        }
        _response.IsSuccess = true;
        _response.StatusCode = HttpStatusCode.OK;
        return Ok(_response);
    }
    [HttpPost]
    [ProducesResponseType(typeof(ApiResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ApiResponse), StatusCodes.Status500InternalServerError)]
    public async Task<ActionResult> Register(SuperAdminUserDTO SuperAdminUserDTO)
    {
        var adminUserDTO = await _superAdminService.CreateAdminAsync(SuperAdminUserDTO);
        if (adminUserDTO is not null)
        {
            _response.IsSuccess = true;
            _response.StatusCode = HttpStatusCode.Created;
            return Created(string.Empty, _response);
        }
        _response.Errors.Add("Super Admin not registered");
        _response.IsSuccess = false;
        _response.StatusCode = HttpStatusCode.InternalServerError;
        return Ok(_response);
    }
}