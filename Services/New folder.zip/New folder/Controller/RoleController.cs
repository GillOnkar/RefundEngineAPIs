using System.Net;
using Microsoft.AspNetCore.Mvc;
using RefundEngine.Application;
using RefundEngine.Application.DTOs;
using RefundEngine.Services.Interfaces;

namespace RefundEngine.Controllers;

[ApiController]
[Route("RefundEngine/api/[controller]/[action]")]
public class RoleController : ControllerBase
{
    private readonly IRoleService _roleService;
    protected ApiResponse _response;
    public RoleController(IRoleService roleService)
    {
        _roleService = roleService;
        _response = new();
    }

    [HttpGet]
    public async Task<IActionResult> GetRoles()
    {
        var roles = await _roleService.GetRolesAsync();
        if (roles.Count() > 0)
        {
            _response.Result = roles;
            _response.StatusCode = HttpStatusCode.OK;
        }
        return Ok(_response);
    }
    [HttpPost]
    [ProducesResponseType(typeof(ApiResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ApiResponse), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> MapRole(RoleMappingDTO roleMappingDTO)
    {
        var result = await _roleService.AddRoleMappingAsync(roleMappingDTO);
        if (result == null)
        {
            // Conflict (email already exists)
            _response.IsSuccess = false;
            _response.Errors.Add("A mapping with this email already exists.");
            _response.StatusCode = HttpStatusCode.Conflict;
            return StatusCode((int)_response.StatusCode, _response);
        }
        // if (_roleService.IsUniqueUserEmailId(roleMappingDTO.EmailId))
        // {
        //     _response.Errors.Add("A mapping with this email already exists.");
        //     _response.IsSuccess = false;
        //     _response.StatusCode = HttpStatusCode.Conflict;
        //     return StatusCode((int)_response.StatusCode, _response);
        // }
         // Created
        _response.Result = result;
        _response.StatusCode = HttpStatusCode.Created;
        return StatusCode((int)_response.StatusCode, _response);
        // var userMapped = await _roleService.AddRoleMappingAsync(roleMappingDTO);
        // if(userMapped != null)
        // {
        //     _response.Result = userMapped;
        //     _response.StatusCode = HttpStatusCode.Created;
        //     return Ok(_response);
        // }
        
    }
}
