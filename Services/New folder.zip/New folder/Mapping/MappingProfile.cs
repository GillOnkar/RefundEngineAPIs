using AutoMapper;
using RefundEngine.Application.DTOs;
using RefundEngine.Application.DTOs.SuperAdmin;
using RefundEngine.Domain.Entities;

namespace RefundEngine.Mapping;

public class MappingProfile : Profile
{
    public MappingProfile()
    {
        CreateMap<RoleLookup, RoleDTO>();
        CreateMap<RoleMapping, RoleMappingDTO>();
        CreateMap<RoleMappingDTO, RoleMapping>();

        CreateMap<AdminUser, SuperAdminUserLoginDTO>().ReverseMap();
        CreateMap<AdminUser, SuperAdminUserDTO>().ReverseMap();    
    }
}