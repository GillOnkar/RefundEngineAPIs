using Microsoft.AspNetCore.Mvc.ApplicationModels;
using Microsoft.EntityFrameworkCore;

namespace RefundEngine.Domain.Entities;

[Index(nameof(Name), IsUnique = true)]
public class UniversityLookup : MasterBaseEntity
{
    public string? Name { get; set; }
}