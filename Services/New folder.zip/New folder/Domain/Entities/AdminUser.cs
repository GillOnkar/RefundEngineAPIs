using System.ComponentModel.DataAnnotations;

namespace RefundEngine.Domain.Entities;

public class AdminUser : BaseEntity
{
    [Required]
    [MaxLength(50)]
    public string? EmailId { get; set; }

    [Required]
    [MaxLength(50)]
    public string? Role { get; set; }

    [Required]
    [MaxLength(100)]
    public string? Password { get; set; }
}