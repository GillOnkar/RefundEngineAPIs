﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace RefundEngine.Migrations
{
    /// <inheritdoc />
    public partial class SeedRoleLookupTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "RoleLookups",
                columns: new[] { "Id", "Alias", "CreatedDate", "IsActive", "Role", "UpdatedDate" },
                values: new object[,]
                {
                    { new Guid("11111111-1111-1111-1111-111111111111"), "super_admin", new DateTime(2025, 10, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), true, "Super Admin", new DateTime(2025, 10, 10, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { new Guid("22222222-2222-2222-2222-222222222222"), "admin", new DateTime(2025, 10, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), true, "Admin", new DateTime(2025, 10, 10, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { new Guid("33333333-3333-3333-3333-333333333333"), "inst_finance", new DateTime(2025, 10, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), true, "Institute Finance", new DateTime(2025, 10, 10, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { new Guid("44444444-4444-4444-4444-444444444444"), "gedu_finance", new DateTime(2025, 10, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), true, "Gedu Finance", new DateTime(2025, 10, 10, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { new Guid("55555555-5555-5555-5555-555555555555"), "admission", new DateTime(2025, 10, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), true, "Admission", new DateTime(2025, 10, 10, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { new Guid("66666666-6666-6666-6666-666666666666"), "inst_admin", new DateTime(2025, 10, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), true, "Institute Administration", new DateTime(2025, 10, 10, 0, 0, 0, 0, DateTimeKind.Unspecified) }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "RoleLookups",
                keyColumn: "Id",
                keyValue: new Guid("11111111-1111-1111-1111-111111111111"));

            migrationBuilder.DeleteData(
                table: "RoleLookups",
                keyColumn: "Id",
                keyValue: new Guid("22222222-2222-2222-2222-222222222222"));

            migrationBuilder.DeleteData(
                table: "RoleLookups",
                keyColumn: "Id",
                keyValue: new Guid("33333333-3333-3333-3333-333333333333"));

            migrationBuilder.DeleteData(
                table: "RoleLookups",
                keyColumn: "Id",
                keyValue: new Guid("44444444-4444-4444-4444-444444444444"));

            migrationBuilder.DeleteData(
                table: "RoleLookups",
                keyColumn: "Id",
                keyValue: new Guid("55555555-5555-5555-5555-555555555555"));

            migrationBuilder.DeleteData(
                table: "RoleLookups",
                keyColumn: "Id",
                keyValue: new Guid("66666666-6666-6666-6666-666666666666"));
        }
    }
}
