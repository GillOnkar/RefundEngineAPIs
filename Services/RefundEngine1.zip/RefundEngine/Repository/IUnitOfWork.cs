using RefundEngine.Domain.Entities;
using RefundEngine.Repository.IRepository;

namespace RefundEngine.Repository;

public interface IUnitOfWork : IDisposable
{
    IGenericRepository<RoleMapping> RoleMappings { get; }
    IGenericRepository<RoleLookup> RoleLookups { get; }
    Task<int> CompleteAsync();
}