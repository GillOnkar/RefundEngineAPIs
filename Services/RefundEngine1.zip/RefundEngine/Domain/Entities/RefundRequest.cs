using System.ComponentModel.DataAnnotations;

namespace RefundEngine.Domain.Entities;

public class RefundRequest : BaseEntity
{

    [Required]
    public string? DGNumber { get; set; }

    [Required]
    public string? Email { get; set; }


    [Required]
    public string? TransactionId { get; set; }

    [Required]
    public string? ReasonToRefund { get; set; }

    public List<string>? Documents { get; set; }


    public DateTime RequestDate { get; set; } = DateTime.UtcNow;

    public string Status { get; set; } = "Requested";
}