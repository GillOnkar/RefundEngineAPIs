using RefundEngine.Application.DTOs;

namespace RefundEngine.Services.Interfaces;

public interface IRoleService
{
    Task<IEnumerable<RoleDTO>> GetRolesAsync();
    bool IsUniqueUserEmailId(string userEmailId);
    Task<RoleMappingDTO> AddRoleMappingAsync(RoleMappingDTO roleMappingDto);
    // Task<IEnumerable<RoleMapping>> GetMappingsByEmailAsync(string EmailId);
    // Task<bool> RemoveRoleMappingAsync(Guid userId, Guid roleId);
}