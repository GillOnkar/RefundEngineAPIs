using System.Security.Claims;
using RefundEngine.Services.Interfaces;

namespace RefundEngine.Services.Implementation;

public class AuthService : IAuthService
{
    string IAuthService.IsValidRole(ClaimsPrincipal user)
    {
        //code to check whether the token provided has valid role or not
        throw new NotImplementedException();
    }
}