using AutoMapper;
using RefundEngine.Application.DTOs;
using RefundEngine.Domain.Entities;

namespace RefundEngine.Mapping;

public class MappingProfile : Profile
{
    public MappingProfile()
    {
        CreateMap<RoleLookup, RoleDTO>();
        CreateMap<RoleMapping, RoleMappingDTO>();
        CreateMap<RoleMappingDTO, RoleMapping>();
    }
}