using System.Security.Cryptography;

namespace RefundEngine.Utility;

public static class PasswordHelper
{
    private const int SaltSize = 16; // 128-bit salt
    private const int KeySize = 32;  // 256-bit derived key
    private const int Iterations = 10000; // PBKDF2 iterations

    // Hash a password
    public static string HashPassword(string password)
    {
        using var rng = RandomNumberGenerator.Create();
        byte[] salt = new byte[SaltSize];
        rng.GetBytes(salt); // generate a cryptographically secure random salt

        using var pbkdf2 = new Rfc2898DeriveBytes(password, salt, Iterations, HashAlgorithmName.SHA256);
        byte[] key = pbkdf2.GetBytes(KeySize); // derive the key from password + salt

        // Combine salt + key into one array
        var hashBytes = new byte[SaltSize + KeySize];
        Array.Copy(salt, 0, hashBytes, 0, SaltSize);
        Array.Copy(key, 0, hashBytes, SaltSize, KeySize);

        return Convert.ToBase64String(hashBytes); // store as string in DB
    }
    
    // Verify password
    public static bool VerifyPassword(string storedHash, string password)
    {
        byte[] hashBytes = Convert.FromBase64String(storedHash);

        // Extract salt from stored hash
        byte[] salt = new byte[SaltSize];
        Array.Copy(hashBytes, 0, salt, 0, SaltSize);

        using var pbkdf2 = new Rfc2898DeriveBytes(password, salt, Iterations, HashAlgorithmName.SHA256);
        byte[] key = pbkdf2.GetBytes(KeySize);

        // Compare derived key with stored key
        for (int i = 0; i < KeySize; i++)
        {
            if (hashBytes[i + SaltSize] != key[i])
                return false;
        }

        return true; // password matches
    }
}