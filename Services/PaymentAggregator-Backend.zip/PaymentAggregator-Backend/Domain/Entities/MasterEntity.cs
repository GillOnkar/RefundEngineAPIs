using System.ComponentModel.DataAnnotations;
namespace RefundEngine.Domain.Entities;

public abstract class MasterBaseEntity
{
    [Key]
    public Guid Id { get; set; }
}