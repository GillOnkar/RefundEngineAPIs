using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RefundEngine.Domain.Entities;

public class RoleMapping : BaseEntity
{
    [Required]
    public Guid RoleId { get; set; }

    [Required]
    public string? EmailId { get; set; }

    [Required]
    public string? FirstName { get; set; }

    [Required]
    public string? LastName { get; set; }

    public bool IsActive { get; set; }

    [ForeignKey(nameof(RoleId))]
    public virtual RoleLookup? Role { get; set; }
}