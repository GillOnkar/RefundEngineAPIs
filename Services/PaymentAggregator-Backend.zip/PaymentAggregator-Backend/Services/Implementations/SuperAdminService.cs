using AutoMapper;
using RefundEngine.Application.DTOs.SuperAdmin;
using RefundEngine.Domain.Entities;
using RefundEngine.Repository;
using RefundEngine.Services.Interfaces;
using RefundEngine.Utility;

namespace RefundEngine.Services.Implementation;

public class SuperAdminService : ISuperAdminService
{
    private readonly IUnitOfWork _unitOfWork;
    private readonly IMapper _mapper;
    public SuperAdminService(IUnitOfWork unitOfWork, IMapper mapper)
    {
        _unitOfWork = unitOfWork;
        _mapper = mapper;
    }
    public async Task<SuperAdminUserDTO> CreateAdminAsync(SuperAdminUserDTO adminUserDTO)
    {
        var superAdmin = await _unitOfWork.AdminUsers.
                       GetAsync(a => a.EmailId!.ToLower() == adminUserDTO.EmailId!.ToLower());
        if (superAdmin is null)
        {
            var adminData = _mapper.Map<AdminUser>(adminUserDTO);
            adminData.Password = PasswordHelper.HashPassword(adminUserDTO.Password!);
            await _unitOfWork.AdminUsers.AddAsync(adminData);
            await _unitOfWork.CompleteAsync();
            return adminUserDTO;
        }
        return null;
    }

    public async Task<bool> ValidatePasswordAsync(SuperAdminUserLoginDTO superAdminUserLoginDTO)
    {
        var superAdmin = await _unitOfWork.AdminUsers.
        GetAsync(a => a.EmailId!.ToLower() == superAdminUserLoginDTO.EmailId!.ToLower());

        if (superAdmin is null)
        {
            return false;
        }

        return PasswordHelper.VerifyPassword(superAdmin.Password!, superAdminUserLoginDTO.Password!);
    }
}