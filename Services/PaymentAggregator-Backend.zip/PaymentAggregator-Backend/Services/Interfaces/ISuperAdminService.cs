using RefundEngine.Application.DTOs.SuperAdmin;

namespace RefundEngine.Services.Interfaces;

public interface ISuperAdminService
{
    Task<SuperAdminUserDTO> CreateAdminAsync(SuperAdminUserDTO adminUserDTO);
    Task<bool> ValidatePasswordAsync(SuperAdminUserLoginDTO superAdminUserLoginDTO);
}